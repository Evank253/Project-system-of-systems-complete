# KETCHUM-SOS-BASE44 — Master Infrastructure Package

Public infrastructure layer for the **KETCHUM SYSTEM-OF-SYSTEMS** — Human-Governed Intelligence Infrastructure.

This package is an **interface layer around existing authoritative systems**. It never replaces, rewrites, or redefines them.

## What is in this package

| Layer | Location | State |
|---|---|---|
| Public application (landing, explorer, live test, evidence, docs) | `/app/frontend` | IMPLEMENTED (development channel) |
| Application API | `/app/backend/server.py` | IMPLEMENTED — TEST_REQUIRED |
| Component registry | `/app/backend/data/registry.json` | IMPLEMENTED |
| Connectors (KCN, MANIFEX, KSI, TEVV, ARENA, Independent Witness) | `/app/backend/connectors/` | INTEGRATION_REQUIRED |
| Evidence system (E0–E5 slots, NOT_MEASURED, hashes, provenance) | `/app/backend/data/evidence_ladder.json` + API | E0–E5 definitions INTEGRATION_REQUIRED |
| Authority model (H0–H3) | `/app/backend/data/authority.json` + API | INTEGRATION_REQUIRED (enforcement via KSI) |
| Security (rate limiting, audit, boundaries) | `/app/backend/server.py` | IMPLEMENTED (basic) — TEST_REQUIRED |
| Acceptance framework | `/app/tests/run_acceptance.py` | IMPLEMENTED — TEST_REQUIRED |
| Deployment | See DEPLOYMENT-SPEC | Development only; production BLOCKED |

## The invariant

```
CAPABILITY ≠ EVIDENCE ≠ VERIFICATION ≠ QUALIFICATION ≠ AUTHORITY
```

## Status vocabulary

Every component is marked exactly one of:

`IMPLEMENTED` · `INTEGRATION_REQUIRED` · `TEST_REQUIRED` · `VERIFICATION_REQUIRED` · `QUALIFICATION_REQUIRED` · `NOT_MEASURED` · `BLOCKED`

Placeholders appear as `[SOURCE_REPOSITORY]`, `[COMMIT_HASH]`, `[API_ENDPOINT]`, `[EVIDENCE_RECORD]`, `[AUTHORITATIVE_DEFINITION_PENDING]` until real data is supplied. **No project data is invented.**

## Hard rules baked into the code

1. An unconfigured connector returns `NOT_CONFIGURED` — never a simulated success.
2. Every evidence record carries a SHA-256 hash and provenance fields.
3. No record asserts an evidence level until authoritative E0–E5 definitions exist.
4. `/api/verification` and `/api/qualification` report zero verified/qualified components, because that is the truth today.
5. Live tests record real outcomes, including `UNAVAILABLE`, `NOT_CONFIGURED`, `FAIL`, and `BLOCKED`.

## Running acceptance checks

```bash
python /app/tests/run_acceptance.py http://localhost:8001
```

## Handoff to an AI builder (Base44 or similar)

Read `BASE44-MASTER-PROMPT.md`. In short: *implement everything marked IMPLEMENTATION-READY; build interfaces and harnesses for everything else; report remaining gates; never fabricate evidence.*
