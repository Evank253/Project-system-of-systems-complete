"""KSI authorization boundary — local stand-in (KSI_LOCAL_POLICY_V0).

The authoritative governance system remains the external KSI. This local engine
can structurally only: ALLOW non-privileged operations, DENY self-authorization
attempts, and DEFER privileged operations to the connected KSI runtime. There is
no code path that grants verification, qualification, or authority — even if a
caller supplies human_approved=true, verified=true, qualified=true, or force."""
import os
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Request
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field

ksi_router = APIRouter(prefix="/api/ksi")

_mclient = AsyncIOMotorClient(os.environ["MONGO_URL"])
kdb = _mclient[os.environ["DB_NAME"]]

POLICY_ID = "KSI_LOCAL_POLICY_V0"

SELF_AUTHORIZATION_OPERATIONS = {"self_grant_authorization", "self_verify", "self_qualify", "self_ratify", "self_delegate"}
PRIVILEGED_OPERATIONS = {
    "evidence.promote", "evidence.delete", "record.modify", "verification.issue",
    "qualification.grant", "authority.delegate", "authority.revoke", "ratify",
    "transition.verification", "transition.qualification", "transition.human_ratification",
}
NON_PRIVILEGED_OPERATIONS = {
    "read.registry", "read.docs", "read.evidence", "read.authority",
    "execution.create", "execution.reproduce", "ai.query", "evidence.integrity_check",
}
IGNORED_FLAG_NAMES = {"human_approved", "human_reviewed", "verified", "qualified", "force", "approved", "authority", "evidence_level", "admin", "bypass"}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def evaluate(operation: str, context: Optional[dict] = None) -> dict:
    op = (operation or "").strip().lower()
    from eil import CONSTITUTION
    if op in SELF_AUTHORIZATION_OPERATIONS:
        decision = "DENY"
        reason = f"Self-authorization attempt '{op}' denied: EIL-03 — NO SELF-ELEVATION: EIL and its constituent systems cannot manufacture, approve, or confer authority upon themselves. [eil:EIL-03] [evidence-rules]"
    elif op in PRIVILEGED_OPERATIONS:
        decision = "DEFERRED"
        reason = f"Privileged operation '{op}': EIL-04 — EVIDENCE DOES NOT AUTHORIZE; and EIL-02 — VALID DELEGATION: no constitutionally authorized delegation type exists in constitution v{CONSTITUTION['version']} → VALID_DELEGATION_VERIFICATION = FALSE → DENY at the authority path. Authority transitions must follow POST /api/eil/delegations. Caller-supplied approval flags are structurally ignored. [eil:EIL-02] [eil:EIL-04]"
    elif op in NON_PRIVILEGED_OPERATIONS:
        decision = "ALLOW"
        reason = "Non-privileged, read-only or controlled-test operation permitted under existing rate limits. Authority is unaffected (EIL-01). [eil:EIL-01]"
    else:
        decision = "DENY"
        reason = f"Unknown operation '{op}' is not in the non-privileged allowlist. Default-deny."
    return {
        "decision": decision,
        "reason": reason,
        "policy_id": POLICY_ID,
        "decided_by": f"{POLICY_ID} (local stand-in — NOT the authoritative KSI)",
        "operation": op,
        "time": _utcnow(),
    }


class EvaluateCreate(BaseModel):
    operation: str = Field(min_length=1, max_length=100)
    context: dict = Field(default_factory=dict)


@ksi_router.post("/evaluate")
async def ksi_evaluate(payload: EvaluateCreate, request: Request):
    result = evaluate(payload.operation, payload.context)
    try:
        await kdb.audit_log.insert_one({"id": str(uuid.uuid4()), "event": "ksi.evaluate", "detail": {"operation": payload.operation, "decision": result["decision"]}, "time": _utcnow()})
    except Exception:
        pass
    return result


@ksi_router.get("")
async def ksi_info():
    return {
        "policy_id": POLICY_ID,
        "invariants": [
            "A system cannot grant itself authorization, verification, qualification, or authority.",
            "Caller-supplied approval flags are structurally ignored — they are never read into any decision.",
            f"{POLICY_ID} can ALLOW non-privileged operations only; privileged operations are DENIED (self-authorization) or DEFERRED (require the connected KSI runtime).",
            "Every evaluation is written to the audit log.",
        ],
        "self_authorization_operations": sorted(SELF_AUTHORIZATION_OPERATIONS),
        "privileged_operations": sorted(PRIVILEGED_OPERATIONS),
        "non_privileged_operations": sorted(NON_PRIVILEGED_OPERATIONS),
        "ignored_flag_names": sorted(IGNORED_FLAG_NAMES),
        "authoritative_system": "KSI (external) — connect via KSI_RUNTIME_ENDPOINT for real ALLOW decisions on privileged operations. Until then every privileged decision is DEFERRED, never granted.",
    }
